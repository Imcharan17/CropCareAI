package com.cropportal.entity;

public enum TicketStatus {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}
