package com.cropportal.service.impl;

import com.cropportal.dto.*;
import com.cropportal.entity.*;
import com.cropportal.exception.ResourceNotFoundException;
import com.cropportal.repository.*;
import com.cropportal.service.TicketService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TicketServiceImpl implements TicketService {
    private final TicketRepository ticketRepository;
    private final FarmerRepository farmerRepository;
    private final DoctorRepository doctorRepository;
    private final DiseaseReportRepository diseaseReportRepository;
    private final TicketMessageRepository messageRepository;
    private final UserRepository userRepository;
    private final SimpMessagingTemplate messagingTemplate;

    @Override
    @Transactional
    public TicketResponse create(String farmerEmail, TicketRequest request) {
        Farmer farmer = farmerRepository.findByUserEmail(farmerEmail).orElseThrow();
        Ticket ticket = new Ticket();
        ticket.setFarmer(farmer);
        ticket.setTitle(request.title());
        ticket.setDescription(request.description());
        ticket.setPriority(request.priority() == null ? "MEDIUM" : request.priority());
        if (request.diseaseReportId() != null) {
            ticket.setDiseaseReport(diseaseReportRepository.findById(request.diseaseReportId()).orElse(null));
        }
        return toResponse(ticketRepository.save(ticket));
    }

    @Override
    public Page<TicketResponse> listForUser(String email, Pageable pageable) {
        User user = userRepository.findByEmail(email).orElseThrow();
        if (user.getRoles().stream().anyMatch(role -> role.getName() == RoleName.ROLE_ADMIN)) {
            return ticketRepository.findAll(pageable).map(this::toResponse);
        }
        if (user.getRoles().stream().anyMatch(role -> role.getName() == RoleName.ROLE_DOCTOR)) {
            return ticketRepository.findByDoctorUserEmail(email, pageable).map(this::toResponse);
        }
        return ticketRepository.findByFarmerUserEmail(email, pageable).map(this::toResponse);
    }

    @Override
    @Transactional
    public TicketResponse assignDoctor(Long ticketId, Long doctorId) {
        Ticket ticket = ticketRepository.findById(ticketId).orElseThrow(() -> new ResourceNotFoundException("Ticket not found"));
        Doctor doctor = doctorRepository.findById(doctorId).orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
        ticket.setDoctor(doctor);
        ticket.setStatus(TicketStatus.IN_PROGRESS);
        return toResponse(ticket);
    }

    @Override
    @Transactional
    public TicketResponse updateStatus(Long ticketId, TicketStatus status, String recommendation) {
        Ticket ticket = ticketRepository.findById(ticketId).orElseThrow(() -> new ResourceNotFoundException("Ticket not found"));
        ticket.setStatus(status);
        ticket.setTreatmentRecommendation(recommendation);
        return toResponse(ticket);
    }

    @Override
    @Transactional
    public MessageResponse addMessage(Long ticketId, String senderEmail, MessageRequest request) {
        Ticket ticket = ticketRepository.findById(ticketId).orElseThrow(() -> new ResourceNotFoundException("Ticket not found"));
        User sender = userRepository.findByEmail(senderEmail).orElseThrow();
        TicketMessage message = new TicketMessage();
        message.setTicket(ticket);
        message.setSender(sender);
        message.setMessage(request.message());
        MessageResponse response = toMessage(messageRepository.save(message));
        messagingTemplate.convertAndSend("/topic/tickets/" + ticketId, response);
        return response;
    }

    @Override
    public List<MessageResponse> messages(Long ticketId) {
        return messageRepository.findByTicketIdOrderByCreatedAtAsc(ticketId).stream().map(this::toMessage).toList();
    }

    private TicketResponse toResponse(Ticket ticket) {
        String doctorName = ticket.getDoctor() == null ? "Unassigned" : ticket.getDoctor().getUser().getFullName();
        return new TicketResponse(ticket.getId(), ticket.getTitle(), ticket.getFarmer().getUser().getFullName(),
                doctorName, ticket.getStatus(), ticket.getPriority(), ticket.getTreatmentRecommendation(), ticket.getCreatedAt());
    }

    private MessageResponse toMessage(TicketMessage message) {
        return new MessageResponse(message.getId(), message.getTicket().getId(), message.getSender().getFullName(),
                message.getMessage(), message.isReadReceipt(), message.getCreatedAt());
    }
}
