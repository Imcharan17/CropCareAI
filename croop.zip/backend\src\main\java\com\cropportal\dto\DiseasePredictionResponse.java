package com.cropportal.dto;

import com.cropportal.entity.SeverityLevel;

public record DiseasePredictionResponse(
        Long reportId,
        String diseaseName,
        Double confidenceScore,
        String affectedArea,
        SeverityLevel severityLevel,
        String recommendedPesticides,
        String recommendedFertilizers,
        String preventionMeasures,
        String expectedRecoveryTime,
        String imageUrl
) {
}
