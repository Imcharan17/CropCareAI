package com.cropportal.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "audit_logs", indexes = @Index(name = "idx_audit_actor", columnList = "actor_id"))
public class AuditLog extends BaseEntity {
    @ManyToOne
    @JoinColumn(name = "actor_id")
    private User actor;
    private String action;
    private String resourceType;
    private Long resourceId;
    private String ipAddress;
    @Column(columnDefinition = "TEXT")
    private String metadata;
}
