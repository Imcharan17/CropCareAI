package com.cropportal.ai;

import com.cropportal.dto.DiseasePredictionResponse;
import com.cropportal.entity.SeverityLevel;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
@ConditionalOnProperty(name = "app.ai.provider", havingValue = "mock", matchIfMissing = true)
public class MockPredictionProvider implements DiseaseDetectionProvider {
    @Override
    public DiseasePredictionResponse predict(MultipartFile image) {
        return new DiseasePredictionResponse(null, "Tomato Late Blight", 0.927, "Leaf canopy and stem edges",
                SeverityLevel.HIGH, "Copper oxychloride spray; Mancozeb as locally approved",
                "Balanced NPK, calcium nitrate, composted organic matter",
                "Remove infected leaves, improve airflow, avoid overhead irrigation, rotate crops",
                "10-14 days with timely treatment", null);
    }

    @Override
    public String name() {
        return "mock";
    }
}
