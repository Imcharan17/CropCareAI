package com.cropportal.ai;

import com.cropportal.dto.DiseasePredictionResponse;
import com.cropportal.entity.SeverityLevel;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
@ConditionalOnProperty(name = "app.ai.provider", havingValue = "tensorflow")
public class TensorFlowProvider implements DiseaseDetectionProvider {
    @Override
    public DiseasePredictionResponse predict(MultipartFile image) {
        return new DiseasePredictionResponse(null, "TensorFlow model unavailable", 0.0, "Not evaluated",
                SeverityLevel.LOW, "Configure model artifacts before using tensorflow provider",
                "Configure model artifacts before using tensorflow provider",
                "Set APP_AI_PROVIDER=mock until the trained model is mounted",
                "Unknown", null);
    }

    @Override
    public String name() {
        return "tensorflow";
    }
}
