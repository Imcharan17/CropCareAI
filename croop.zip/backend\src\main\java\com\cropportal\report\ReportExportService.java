package com.cropportal.report;

import com.cropportal.entity.DiseaseReport;
import com.cropportal.repository.DiseaseReportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ReportExportService {
    private final DiseaseReportRepository diseaseReportRepository;

    public String csv() {
        StringBuilder csv = new StringBuilder("Report ID,Disease,Confidence,Severity,Affected Area,Recovery Time\n");
        for (DiseaseReport report : diseaseReportRepository.findAll()) {
            csv.append(report.getId()).append(',')
                    .append(escape(report.getDiseaseName())).append(',')
                    .append(report.getConfidenceScore()).append(',')
                    .append(report.getSeverityLevel()).append(',')
                    .append(escape(report.getAffectedArea())).append(',')
                    .append(escape(report.getExpectedRecoveryTime())).append('\n');
        }
        return csv.toString();
    }

    public byte[] pdf() {
        String text = "CropCare Disease Reports\n\n" + csv();
        String stream = "BT /F1 11 Tf 50 760 Td (" + text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)").replace("\n", ") Tj T* (") + ") Tj ET";
        String body = "1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
                + "2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n"
                + "3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<</Font<</F1 4 0 R>>>>/Contents 5 0 R>>endobj\n"
                + "4 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n"
                + "5 0 obj<</Length " + stream.length() + ">>stream\n" + stream + "\nendstream endobj\n";
        return ("%PDF-1.4\n" + body + "trailer<</Root 1 0 R>>\n%%EOF").getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }

    private String escape(String value) {
        if (value == null) {
            return "";
        }
        return '"' + value.replace("\"", "\"\"") + '"';
    }
}
