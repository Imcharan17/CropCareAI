package com.cropportal.service.impl;

import com.cropportal.ai.DiseaseDetectionProvider;
import com.cropportal.dto.DiseasePredictionResponse;
import com.cropportal.entity.*;
import com.cropportal.exception.BadRequestException;
import com.cropportal.repository.*;
import com.cropportal.service.DiseaseDetectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DiseaseDetectionServiceImpl implements DiseaseDetectionService {
    private final FarmerRepository farmerRepository;
    private final CropRepository cropRepository;
    private final ImageUploadRepository imageUploadRepository;
    private final DiseaseReportRepository diseaseReportRepository;
    private final DiseaseDetectionProvider detectionProvider;
    @Value("${app.upload-dir}")
    private String uploadDir;

    @Override
    @Transactional
    public DiseasePredictionResponse detect(String farmerEmail, Long cropId, MultipartFile file) {
        validateImage(file);
        Farmer farmer = farmerRepository.findByUserEmail(farmerEmail).orElseThrow();
        Crop crop = cropId == null ? null : cropRepository.findById(cropId).orElse(null);
        ImageUpload image = store(farmer, file);
        DiseaseReport report = runPrediction(farmer, crop, image, detectionProvider.predict(file));
        diseaseReportRepository.save(report);
        return toResponse(report);
    }

    private void validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new BadRequestException("Image is required");
        String type = file.getContentType() == null ? "" : file.getContentType().toLowerCase(Locale.ROOT);
        if (!type.equals("image/jpeg") && !type.equals("image/jpg") && !type.equals("image/png")) {
            throw new BadRequestException("Only JPG, JPEG and PNG images are supported");
        }
    }

    private ImageUpload store(Farmer farmer, MultipartFile file) {
        try {
            Files.createDirectories(Path.of(uploadDir));
            String ext = file.getOriginalFilename() == null ? ".jpg" : file.getOriginalFilename().replaceAll("^.*(\\.[A-Za-z0-9]+)$", "$1");
            String stored = UUID.randomUUID() + ext;
            Path target = Path.of(uploadDir, stored);
            Files.copy(file.getInputStream(), target);
            ImageUpload image = new ImageUpload();
            image.setFarmer(farmer);
            image.setOriginalFileName(file.getOriginalFilename());
            image.setStoredFileName(stored);
            image.setContentType(file.getContentType());
            image.setSizeBytes(file.getSize());
            image.setStoragePath(target.toString());
            return imageUploadRepository.save(image);
        } catch (IOException ex) {
            throw new BadRequestException("Could not store image");
        }
    }

    private DiseaseReport runPrediction(Farmer farmer, Crop crop, ImageUpload image, DiseasePredictionResponse prediction) {
        DiseaseReport report = new DiseaseReport();
        report.setFarmer(farmer);
        report.setCrop(crop);
        report.setImageUpload(image);
        report.setDiseaseName(prediction.diseaseName());
        report.setConfidenceScore(prediction.confidenceScore());
        report.setAffectedArea(prediction.affectedArea());
        report.setSeverityLevel(prediction.severityLevel());
        report.setRecommendedPesticides(prediction.recommendedPesticides());
        report.setRecommendedFertilizers(prediction.recommendedFertilizers());
        report.setPreventionMeasures(prediction.preventionMeasures());
        report.setExpectedRecoveryTime(prediction.expectedRecoveryTime());
        return report;
    }

    private DiseasePredictionResponse toResponse(DiseaseReport report) {
        return new DiseasePredictionResponse(report.getId(), report.getDiseaseName(), report.getConfidenceScore(),
                report.getAffectedArea(), report.getSeverityLevel(), report.getRecommendedPesticides(),
                report.getRecommendedFertilizers(), report.getPreventionMeasures(), report.getExpectedRecoveryTime(),
                "/api/files/" + report.getImageUpload().getStoredFileName());
    }
}
