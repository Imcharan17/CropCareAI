package com.cropportal.controller;

import com.cropportal.entity.DiseaseReport;
import com.cropportal.report.ReportExportService;
import com.cropportal.repository.DiseaseReportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportController {
    private final DiseaseReportRepository diseaseReportRepository;
    private final ReportExportService reportExportService;

    @GetMapping
    public Page<DiseaseReport> reports(Authentication authentication, Pageable pageable) {
        return diseaseReportRepository.findByFarmerUserEmail(authentication.getName(), pageable);
    }

    @GetMapping("/export.csv")
    public ResponseEntity<String> exportCsv() {
        String csv = reportExportService.csv();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=disease-reports.csv")
                .contentType(MediaType.TEXT_PLAIN)
                .body(csv);
    }

    @GetMapping("/export.xlsx")
    public ResponseEntity<String> exportExcel() {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=disease-reports.xlsx")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(reportExportService.csv());
    }

    @GetMapping("/export.pdf")
    public ResponseEntity<byte[]> exportPdf() {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=disease-reports.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(reportExportService.pdf());
    }
}
